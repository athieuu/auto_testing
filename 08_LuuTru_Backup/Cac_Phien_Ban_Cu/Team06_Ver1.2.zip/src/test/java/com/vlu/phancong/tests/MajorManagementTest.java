package com.vlu.phancong.tests;

import com.vlu.phancong.pages.MajorManagementPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class MajorManagementTest extends BaseTest {

    @Test(priority = 1, description = "TC_MAJOR_01 - Xem danh sách ngành học Khoa CNTT (F.4.1)")
    public void testViewMajorList() {
        MajorManagementPage majorPage = new MajorManagementPage(driver);
        majorPage.goToMajorManagement();
        Assert.assertTrue(driver.getCurrentUrl().contains("Major") || driver.getPageSource().contains("ngành"),
                "Không thể truy cập trang Quản lý ngành học!");
    }

    @Test(priority = 2, description = "TC_MAJOR_02 - Thêm mới ngành học thành công (F.4.2)")
    public void testCreateNewMajor() {
        MajorManagementPage majorPage = new MajorManagementPage(driver);
        majorPage.goToMajorManagement();
        majorPage.createMajor("7480201_TEST", "Công nghệ phần mềm Test");
        Assert.assertTrue(majorPage.isMajorExists("Công nghệ phần mềm Test"),
                "Tạo ngành học mới không thành công!");
    }

    @Test(priority = 3, description = "TC_MAJOR_04 - Tìm kiếm ngành học theo từ khóa (F.4.5)")
    public void testSearchMajor() {
        MajorManagementPage majorPage = new MajorManagementPage(driver);
        majorPage.goToMajorManagement();
        majorPage.searchMajor("Phần mềm");
        Assert.assertTrue(driver.getPageSource().contains("Phần mềm"),
                "Tìm kiếm ngành học không thành công!");
    }
}
