package com.vlu.phancong.tests;

import com.vlu.phancong.pages.TimetableManagementPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TimetableManagementTest extends BaseTest {

    @Test(priority = 1, description = "TC_TIME_01 - Xem thời khóa biểu toàn khoa theo tuần (F.5.3)")
    public void testViewTimetable() {
        TimetableManagementPage timetablePage = new TimetableManagementPage(driver);
        timetablePage.goToTimetableManagement();
        Assert.assertTrue(driver.getCurrentUrl().contains("Timetable") || driver.getPageSource().contains("thời khóa biểu"),
                "Không thể truy cập trang Thời khóa biểu!");
    }

    @Test(priority = 2, description = "TC_TIME_04 - Export thời khóa biểu ra file Excel (F.5.2)")
    public void testExportTimetable() {
        TimetableManagementPage timetablePage = new TimetableManagementPage(driver);
        timetablePage.goToTimetableManagement();
        timetablePage.exportTimetable();
        Assert.assertTrue(true, "Yêu cầu export thời khóa biểu đã được gửi thành công!");
    }
}
