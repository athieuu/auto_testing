package com.vlu.phancong.tests;

import com.vlu.phancong.pages.StatisticsPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class StatisticsTest extends BaseTest {

    @Test(priority = 1, description = "TC_STAT_01 - Xem thống kê số giờ dạy theo học kỳ (F.6.1)")
    public void testViewHoursInTerm() {
        StatisticsPage statsPage = new StatisticsPage(driver);
        statsPage.goToStatistics();
        statsPage.viewHoursInTerm();
        Assert.assertTrue(statsPage.isStatisticsDisplayed(), "Không thể hiển thị bảng thống kê giờ dạy theo học kỳ!");
    }

    @Test(priority = 2, description = "TC_STAT_02 - Xem thống kê số giờ dạy theo năm học (F.6.2)")
    public void testViewHoursInYear() {
        StatisticsPage statsPage = new StatisticsPage(driver);
        statsPage.goToStatistics();
        statsPage.viewHoursInYear();
        Assert.assertTrue(statsPage.isStatisticsDisplayed(), "Không thể hiển thị bảng thống kê giờ dạy theo năm học!");
    }

    @Test(priority = 3, description = "TC_STAT_03 - Xem thống kê số môn học phân công trong học kỳ (F.6.3)")
    public void testViewSubjectsInTerm() {
        StatisticsPage statsPage = new StatisticsPage(driver);
        statsPage.goToStatistics();
        statsPage.viewSubjectsInTerm();
        Assert.assertTrue(statsPage.isStatisticsDisplayed(), "Không thể hiển thị bảng thống kê môn học!");
    }
}
