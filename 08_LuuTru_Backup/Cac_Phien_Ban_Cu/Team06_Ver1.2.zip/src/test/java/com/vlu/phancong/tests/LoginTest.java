package com.vlu.phancong.tests;

import com.vlu.phancong.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginTest extends BaseTest {

    @Test(priority = 1, description = "F.1.1 - Đăng nhập tài khoản BCN Khoa với thông tin hợp lệ")
    public void testLoginFacultyBoardSuccess() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("bcnkhoa.cntt@vanlanguni.edu.vn", "Password123");
        Assert.assertTrue(loginPage.isLoggedInSuccessfully(), "Đăng nhập BCN Khoa không thành công!");
    }
}
