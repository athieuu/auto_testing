package com.vlu.phancong.tests;

import com.vlu.phancong.pages.TermManagementPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TermManagementTest extends BaseTest {

    @Test(priority = 1, description = "F.3.1 - Xem danh sách học kỳ BCN Khoa")
    public void testViewTermList() {
        TermManagementPage termPage = new TermManagementPage(driver);
        termPage.goToTermManagement();
        Assert.assertTrue(driver.getCurrentUrl().contains("Term"), "Không thể truy cập trang Quản lý học kỳ!");
    }

    @Test(priority = 2, description = "F.3.2 - Tạo học kỳ mới trong hệ thống")
    public void testCreateNewTerm() {
        TermManagementPage termPage = new TermManagementPage(driver);
        termPage.goToTermManagement();
        termPage.createTerm("HK999", "Học kỳ 3 Năm học 2026-2027 (Test)");
        Assert.assertTrue(termPage.isTermExists("HK999"), "Tạo học kỳ mới không thành công!");
    }
}
