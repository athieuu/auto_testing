package com.vlu.phancong.tests;

import com.vlu.phancong.pages.RemunerationPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class RemunerationTest extends BaseTest {

    @Test(priority = 1, description = "TC_REMU_01 - Xem bảng tính thù lao giảng dạy theo học kỳ (F.7.1)")
    public void testViewRemunerationTable() {
        RemunerationPage remunerationPage = new RemunerationPage(driver);
        remunerationPage.goToRemuneration();
        Assert.assertTrue(remunerationPage.isRemunerationTableDisplayed(), "Không thể hiển thị bảng tính thù lao!");
    }

    @Test(priority = 2, description = "TC_REMU_03 - Xuất bảng tính thù lao ra file Excel (F.7.19)")
    public void testExportRemuneration() {
        RemunerationPage remunerationPage = new RemunerationPage(driver);
        remunerationPage.goToRemuneration();
        remunerationPage.exportRemuneration();
        Assert.assertTrue(true, "Yêu cầu xuất Excel bảng tính thù lao thành công!");
    }
}
