package com.vlu.phancong.tests;

import com.vlu.phancong.pages.UserManagementPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class UserManagementTest extends BaseTest {

    @Test(priority = 1, description = "F.2.1 - Xem danh sách người dùng BCN Khoa")
    public void testViewUserList() {
        UserManagementPage userPage = new UserManagementPage(driver);
        userPage.goToUserManagement();
        Assert.assertTrue(driver.getCurrentUrl().contains("User"), "Không thể truy cập trang Quản lý người dùng!");
    }

    @Test(priority = 2, description = "F.2.2 - Tạo người dùng/Giảng viên mới")
    public void testCreateNewUser() {
        UserManagementPage userPage = new UserManagementPage(driver);
        userPage.goToUserManagement();
        userPage.createUser("GV999", "Nguyễn Văn Test", "nguyenvan.test@vanlanguni.edu.vn", "Giảng viên");
        Assert.assertTrue(userPage.isUserDisplayedInTable("GV999"), "Tạo giảng viên mới không thành công!");
    }

    @Test(priority = 3, description = "F.2.5 - Tìm kiếm người dùng theo mã giảng viên")
    public void testSearchUser() {
        UserManagementPage userPage = new UserManagementPage(driver);
        userPage.goToUserManagement();
        userPage.searchUser("GV999");
        Assert.assertTrue(userPage.isUserDisplayedInTable("GV999"), "Tìm kiếm người dùng không thành công!");
    }
}
